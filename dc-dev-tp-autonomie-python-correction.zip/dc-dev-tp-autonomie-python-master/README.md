# Blog TP DEV WEB 
_Digital Campus_

pour installer les packages python lancez la commande : 
`pip install -r requirements.txt`