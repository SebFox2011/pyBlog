# Python TP1 (partie 1)
Installez Python 3 sur votre machine si ce n’est pas déjà fait.
* Soit avec un IDE (PyCharm, VSCode)
* Soit en ligne de commande (vérifiez que vous avez bien une version > 3.4 )

1. Créez un petit programme python, où vous allez devoir deviner un nombre que l’ordinateur aura choisi au hasard.
Utilisez la bibliothèque `random` avec sa méthode `randint(a, b)`  pour générer un nombre aléatoire

2. Modifiez votre programme pour gérer les erreurs (si l’utilisateur ne rentre pas de nombre par exemple.)
3. Ajouter la possibilité de jouer à 2 joueurs. (celui qui fait le moins d’essai gagne)

# Python TP1 (Partie 2)
Dans ce TP nous allons faire une application de gestion de stock / e-commerce.

1. Créez une classe « Article » avec comme attributs un identifiant, un nom, une description et un prix.
Prévoyez une méthode pour afficher les détails d’un article.
2. Créez une classe « Stock » et une classe « StockEntry » pour modéliser un stock. La classe « StockEntry » aura comme attribut un article, et une quantité, tandis que la classe « Stock » aura comme attribut une liste de « StockEntry ».
Prévoyez une méthode pour afficher l’état du stock. (et affiche le prix total du stock)
3. Créez une classe « Menu » qui va : 

		* Afficher les actions possibles
		* Récupérer l’action de l’utilisateur (avec l’instruction `input()`) 
		
Les actions seront les suivantes : 
		* Afficher l’état du stock
		* Ajouter un nouvel article
		* Modifier la quantité d’un article
		* Retirer un article
		
5. Créer un fichier application.py qui sera notre point d’entrée (notre fichier python qu’il faudra lancer pour démarrer l’application)
Dans celui-ci il faudra réaliser une boucle while, qui à chaque tour présentera le menu et demandera à l’utilisateur son action.
6. Ajoutez à la suite du choix de l’utilisateur une condition multiple qui va exécuter l’action (Si on choisi « Afficher le sotck » on appelle notre classe stock pour afficher le sock) 