import random

lowRange = 0
highRange = 100

def readUserNumber(numPlayer):
    intNumber = -1
    while intNumber < lowRange or intNumber > highRange :
        userInput = input('[Player {}] Entrez un nombre entre {} et {} ? '.format(numPlayer, lowRange, highRange))
        try:
            intNumber = int(userInput)
            if intNumber < lowRange or intNumber > highRange:
                print("Votre nombre n'est pas compris entre {} et {}.".format(lowRange, highRange))
        except:
            print('Ce n\'est pas un nombre')
    return intNumber

def checkNumbers(numPlayer, toGuess, playerNumber):
    if playerNumber > toGuess:
        print("[Player {}] Plus petit...".format(numPlayer))
        return False
    elif playerNumber < toGuess:
        print("[Player {}] Plus grand...".format(numPlayer))
        return False
    return True

numberToGuess = random.randint(lowRange, highRange)
numberOfTries = 1

winner = ''
didWin = False

while not didWin:
    user1Number = readUserNumber('1')
    user2Number = readUserNumber('2')
    if checkNumbers('1', numberToGuess, user1Number):
        winner = 'Player 1'
        didWin = True
    if checkNumbers('2', numberToGuess, user2Number):
        if didWin:
            winner = 'Égalité'
        else:
            winner = 'Player 2'
            didWin = True
    numberOfTries += 1
    

print("Bravo vous avez trouvé en {} essais, le gagnant est {}".format(numberOfTries, winner))
