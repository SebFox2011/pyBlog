class Point:
    pointCount = 0
    def __init__(self, x = 0, y = 0):
        self.x = x
        self.y = y
        Point.pointCount += 1
    
    def print(self):
       print('Point x={},y={}'.format(self.x, self.y))

    def move(self, deltaX, deltaY):
        self.x += deltaX
        self.y += deltaY
    
    @classmethod
    def printNumberOfPoints(cls):
        print('Nombre de points : '+str(cls.pointCount))


class Point3D(Point):
    def __init__(self, x, y, z):
        Point.__init__(self, x, y)
        self.z = z
    
    def print(self):
        print('Point x={},y={},z={}'.format(self.x, self.y, self.z))


pt1 = Point(3,5)
pt1.move(-3, -5)
pt1.print()
pt2 = Point()
pt2.move(17,10)
pt2.print()
pt3 = Point3D(1,2,3)
pt3.print()

Point.printNumberOfPoints()

