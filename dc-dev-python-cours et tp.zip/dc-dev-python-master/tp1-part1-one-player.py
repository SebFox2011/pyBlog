import random

lowRange = 0
highRange = 100

def readUserNumber():
    intNumber = -1
    while intNumber < lowRange or intNumber > highRange :
        userInput = input('Entrez un nombre entre {} et {} ? '.format(lowRange, highRange))
        #userInput = input('Entrez un nombre entre '+str(lowRange)+' et '+str(highRange)+' ? ')
        try:
            intNumber = int(userInput)
            if intNumber < lowRange or intNumber > highRange:
                print("Votre nombre n'est pas compris entre {} et {}.".format(lowRange, highRange))
        except:
            print('Ce n\'est pas un nombre')
    return intNumber

numberToGuess = random.randint(lowRange, highRange)
numberOfTries = 1
userNumber = readUserNumber()

while userNumber != numberToGuess:
    if userNumber > numberToGuess:
        print("Plus petit...")
        userNumber = readUserNumber()
    elif userNumber < numberToGuess:
        print("Plus grand...")
        userNumber = readUserNumber()
    numberOfTries += 1
    
print("Bravo vous avez trouvé en {} essais".format(numberOfTries))
