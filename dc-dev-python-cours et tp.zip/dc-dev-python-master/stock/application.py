from menu import Menu
from stock import stock

menu = Menu()

userAction = -1

while userAction != 5:
    menu.displayMenu()
    userAction = menu.readUserAction()
    if userAction == 1 :
        stock.print()
    elif userAction == 2 :
        stock.addArticle()
    elif userAction == 3 :
        #Action 3
        print("action 3")
    else:
        #Ne devrait pas arriver.
        print("...")

print("Au revoir...")